#pragma once
#include <Arduino.h>

void sensorsInit();
void sensorsStartTask();
bool checkSensorHealth();
