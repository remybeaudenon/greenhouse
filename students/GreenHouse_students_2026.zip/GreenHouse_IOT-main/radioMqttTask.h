#pragma once

void mqttInit();
void mqttStartTask();
